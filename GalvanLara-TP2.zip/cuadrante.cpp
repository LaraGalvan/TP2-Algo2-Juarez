#include "cuadrante.h"


Cuadrante::Cuadrante(){

	this->nombre = "";
	this->minimo_x = 0;
	this->maximo_x = 0;
	this->minimo_y = 0;
	this->maximo_y = 0;
}


Cuadrante::Cuadrante(string nombre, int minimo_x, int maximo_x, int minimo_y, int maximo_y){

	this->nombre = nombre;
	this->minimo_x = minimo_x;
	this->maximo_x = maximo_x;
	this->minimo_y = minimo_y;
	this->maximo_y = maximo_y;

}


string Cuadrante::obtener_nombre(){

	return (this->nombre);
}



int Cuadrante::obtener_minimo_x(){

	return (this->minimo_x);
}


int Cuadrante::obtener_maximo_x(){

	return (this->maximo_x);
}


int Cuadrante::obtener_minimo_y(){

	return (this->minimo_y);
}


int Cuadrante::obtener_maximo_y(){

	return (this->maximo_y);
}
