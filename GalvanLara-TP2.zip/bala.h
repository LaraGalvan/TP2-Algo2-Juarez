#ifndef BALA_H_
#define BALA_H_

#include "elemento.h"
#include "constantes.h"

class Bala : public Elemento {

private:
	int cantidad_balas;

public:
	//constructor
	Bala(string nombre, int coordenada_x, int coordenada_y, int balas);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	//POST: Devuelve la cantidad asociada al elemento
	int devolver_cantidad();


};


#endif /* BALA_H_ */
