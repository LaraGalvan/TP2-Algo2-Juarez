#include "humano.h"

Humano::Humano(string nombre, int coordenada_x, int coordenada_y) : Ser(nombre, coordenada_x, coordenada_y){


}


void Humano::mostrar(){

	cout << "\t NOMBRE PERSONAJE --> " << this->nombre << endl;
}


char Humano::mostrar_caracter(){

	return HUMANO;
}

string Humano::tipo_objeto(){

	return ELEMENTO_HUMANO;
}


int Humano::devolver_cantidad(){

	return CANTIDAD_UNO;
}
