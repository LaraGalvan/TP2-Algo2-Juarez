#ifndef HUMANO_H_
#define HUMANO_H_

#include "ser.h"
#include "constantes.h"

class Humano : public Ser {

public:
	//Costructor
	Humano(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();
};


#endif /* HUMANO_H_ */
