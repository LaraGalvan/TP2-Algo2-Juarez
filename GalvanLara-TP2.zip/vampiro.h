#ifndef VAMPIRO_H_
#define VAMPIRO_H_

#include "monstruo.h"
#include "constantes.h"

class Vampiro : public Monstruo {


public:
	//Constructor
	Vampiro(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();
};


#endif /* VAMPIRO_H_ */
