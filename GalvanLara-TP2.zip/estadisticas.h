#ifndef ESTADISTICAS_H_
#define ESTADISTICAS_H_

#include "objeto.h"
#include <iomanip>
#include "constantes.h"

class Estadisticas{

private:
	int cant_humanos;
	int cant_zombi;
	int cant_vampiros;
	int cant_cruces;
	int cant_estacas;
	int cant_escopetas;
	int cant_agua;
	int cant_balas;

public:
	//Constructor
	//PRE: -
	//POST: Inicializa los contadores
	Estadisticas();

	//PRE: Recibe un string que representa al elemento leido
	//POST: Incrementara los contadores menos los de agua y bala
	void incrementar_contadores(string elemento);


	//PRE: Recibe el nombre del elemento junto a su cantidad asociada
	//POST: Incrementara los contadores de agua o bala
	void incrementar_contador_cantidad(string elemento, int cantidad);


	//PRE: Recibe el nombre del elemento junto a la cantidad a decrementar
	//POST: Se decrementan los contadores
	void decrementar_contadores(string elemento, int cantidad);


	//POST: La funcion devuelve el porcentaje de humanos sobre el total
	float porcentaje_humanos();


	//POST:  La funcion devuelve el porcentaje de los vampiros
	float porcentaje_vampiros();


	//POST:  La funcion devuelve el porcentaje de los zombis
	float porcentaje_zombis();


	//POST: La función devuelve el porcentaje de las escopetas sobre el total
	float porcentaje_escopeta();


	//POST: La funcion devuelve el porcentaje de las estacas
	float porcentaje_estacas();


	//POST: La funcion devuelve el porcentaje de las cruces
	float porcentaje_cruces();


	//POST: La funcion devuelve el porcentaje de agua
	float porcentaje_agua();


	//POST: La funcion devuelve el porcentaje de las balas
	float porcentaje_balas();


	//POST: Se imprime el cuadro de las estadisticas y porcentajes de los elementos
	void mostrar_estadisticas();


	//Destructor
	~Estadisticas(){};

};



#endif /* ESTADISTICAS_H_ */
