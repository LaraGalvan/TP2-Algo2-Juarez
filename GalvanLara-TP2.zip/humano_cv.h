#ifndef HUMANO_CV_H_
#define HUMANO_CV_H_

#include "humano.h"
#include "constantes.h"

class HumanoCV : public Humano {
public:
	//constructor
	HumanoCV(string nombre, int coordenada_x, int coordenada_y);

	void mostrar();

	char mostrar_caracter();

	string tipo_objeto();

	int devolver_cantidad();
};


#endif /* HUMANO_CV_H_ */
