#ifndef ELEMENTO_H_
#define ELEMENTO_H_

#include "objeto.h"

class Elemento : public Objeto {

public:

	//Constructor
	Elemento(string nombre, int coordenada_x, int coordenada_y);


	virtual void mostrar() = 0;


	virtual char mostrar_caracter() = 0;


	virtual string tipo_objeto() = 0;


	virtual int devolver_cantidad() = 0;

};

#endif /* ELEMENTO_H_ */
