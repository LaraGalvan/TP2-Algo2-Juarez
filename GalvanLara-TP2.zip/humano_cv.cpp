#include "humano_cv.h"

HumanoCV::HumanoCV(string nombre, int coordenada_x, int coordenada_y) : Humano(nombre, coordenada_x, coordenada_y){

}



void HumanoCV::mostrar(){

	cout << "\t NOMBRE PERSONAJE -->" << this->nombre << endl;
}


char HumanoCV::mostrar_caracter(){

	return HUMANO_CV;
}


string HumanoCV::tipo_objeto(){

	return ELEMENTO_HUMANO;
}


int HumanoCV::devolver_cantidad(){

	return CANTIDAD_UNO;
}
