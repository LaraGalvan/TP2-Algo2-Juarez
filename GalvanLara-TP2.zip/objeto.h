#ifndef OBJETO_H_
#define OBJETO_H_

#include <iostream>
using namespace std;

class Objeto{

protected:
	string nombre;
	int coordenada_x;
	int coordenada_y;

public:
	//Constructor con parametros
	//PRE: Recibe un nombre junto a su coordenada (x,y)
	//POST: Se le asignan a los atributos los parametros recibidos
	Objeto(string nombre, int coordenada_x, int coordenada_y);


	//POST: Muestra por pantalla la información del elemento
	virtual void mostrar() = 0;


	//POST: Muestra el caracter correspondiente al elemento
	virtual char mostrar_caracter() = 0;


	//POST: Devuelve el atributo nombre
	string devolver_nombre();


	//POST: Devuelve el nombre de la clase del objeto
	virtual string tipo_objeto() = 0;


	//POST: Devuelve la cantidad del objeto
	virtual int devolver_cantidad() = 0;


	//Destructor
	virtual ~Objeto();
};

#endif /* OBJETO_H_ */
