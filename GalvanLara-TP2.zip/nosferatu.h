#ifndef NOSFERATU_H_
#define NOSFERATU_H_

#include "vampiro.h"

class Nosferatu : public Vampiro {
public:
	//Constructor
	Nosferatu(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();

};


#endif /* NOSFERATU_H_ */
