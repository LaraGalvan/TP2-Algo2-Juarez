#include "monstruo.h"

Monstruo::Monstruo(string nombre, int coordenada_x, int coordenada_y) : Ser(nombre, coordenada_x, coordenada_y){

}
