#include "elemento.h"

Elemento::Elemento(string nombre, int coordenada_x, int coordenada_y) : Objeto(nombre, coordenada_x, coordenada_y){

}

