#ifndef CRUZ_H_
#define CRUZ_H_

#include "elemento.h"
#include "constantes.h"

class Cruz : public Elemento {

public:

	Cruz(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();
};



#endif /* CRUZ_H_ */
