#ifndef SER_H_
#define SER_H_

#include "objeto.h"

class Ser : public Objeto {

public:
	//Constructor
	Ser(string nombre, int coordenada_x, int coordenada_y);


	virtual void mostrar() = 0;


	virtual char mostrar_caracter() = 0;


	virtual string tipo_objeto() = 0;


	virtual int devolver_cantidad() = 0;

};



#endif /* SER_H_ */
