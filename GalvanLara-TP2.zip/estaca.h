#ifndef ESTACA_H_
#define ESTACA_H_

#include "elemento.h"
#include "constantes.h"

class Estaca : public Elemento {

public:
	//constructor
	Estaca(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();
};


#endif /* ESTACA_H_ */
