#include "juego.h"

Juego::Juego(string archivo){

	ifstream datos;
	datos.open(archivo);
	string linea, fil, col;
	int filas, columnas;
	porcentajes = new Estadisticas();

	if(!datos) cout << ERROR_APERTURA_ARCHIVO << endl;

	else {
		getline(datos, fil, ESPACIO);
		getline(datos, col);
		filas = stoi(fil);
		columnas = stoi(col);
		tablero = new Tablero(filas, columnas);

		while(getline(datos, linea)){

			stringstream entrada(linea);
			string elemento, guardado;
			int posicion_x, posicion_y;
			int cant_dosis, cant_balas;

			getline(entrada, elemento, ESPACIO);
			guardado = elemento;
			if(elemento == "agua"){
				entrada >> cant_dosis;
				getline(entrada, elemento, ESPACIO);
				getline(entrada, elemento, '(');
				entrada >> posicion_x;
				getline(entrada, elemento, ',');
				getline(entrada, elemento, ESPACIO);
				entrada >> posicion_y;
				tablero->agregar_elementos_cantidad(guardado, posicion_x, posicion_y, cant_dosis);
				porcentajes->incrementar_contador_cantidad(guardado, cant_dosis);
			}
			else if(elemento == "bala"){

				entrada >> cant_balas;
				getline(entrada, elemento, ESPACIO);
				getline(entrada, elemento, '(');
				entrada >> posicion_x;
				getline(entrada, elemento, ',');
				getline(entrada, elemento, ESPACIO);
				entrada >> posicion_y;
				tablero->agregar_elementos_cantidad(guardado, posicion_x, posicion_y, cant_balas);
				porcentajes->incrementar_contador_cantidad(guardado, cant_balas);
			}
			else{
				getline(entrada, elemento, '(');
				entrada >> posicion_x;
				getline(entrada, elemento, ',');
				getline(entrada, elemento, ESPACIO);
				entrada >> posicion_y;
				tablero->agregar_elemento(guardado, posicion_x, posicion_y);
				porcentajes->incrementar_contadores(guardado);
			}
		}
	}
	datos.close();
}


void Juego::mostrar_tablero(){

	tablero->imprimir_tablero();
}


void Juego::mostrar_porcentajes(){

	porcentajes->mostrar_estadisticas();
}


bool Juego::validar_coordenada_x(int &posicion_x){

	return ((posicion_x >= 0) && (posicion_x < tablero->devolver_filas()));
}


bool Juego::validar_coordenada_y(int &posicion_y){

	return ((posicion_y >= 0) && (posicion_y < tablero->devolver_columnas()));
}



int Juego::pedir_cantidad(){

	int cantidad;
	cout << "INGRESE CANTIDAD PARA AGREGAR: ";
	cin >> cantidad;

	while(cantidad < 0){
		cout << "CANTIDAD INCORRECTA. Por favor ingrese un valor mayor a cero: ";
		cin >> cantidad;
	}
	return cantidad;
}


void Juego::dar_alta(string &nombre, int &coordenada_x, int &coordenada_y){


	if(nombre == "agua" || nombre == "bala"){

		int cantidad = pedir_cantidad();

		if(tablero->agregar_elementos_cantidad(nombre, coordenada_x, coordenada_y, cantidad)){
			cout << "\t DADA DE ALTA EXITOSA" << endl;
			porcentajes->incrementar_contador_cantidad(nombre, cantidad);
		}
		else
			cout << "\t POSICION OCUPADA" << endl;
	}
	else{ //para el resto de elementos
		if(tablero->agregar_elemento(nombre, coordenada_x, coordenada_y)){
			cout << "\t DADA DE ALTA EXITOSA" << endl;
			porcentajes->incrementar_contadores(nombre);
		}
		else
			cout << "\t POSICION OCUPADA" << endl;
	}
}

void Juego::dar_baja(int &posicion_x, int &posicion_y){


	if(tablero->obtener_objeto(posicion_x, posicion_y)){

		cout << "\t DADA DE BAJA EXITOSA!" << endl;
		int cantidad = (tablero->obtener_objeto(posicion_x, posicion_y))->devolver_cantidad();
		string tipo_objeto = (tablero->obtener_objeto(posicion_x, posicion_y))->tipo_objeto();
		tablero->dar_baja(posicion_x, posicion_y);
		porcentajes->decrementar_contadores(tipo_objeto, cantidad);
		cout << "\t ELEMENTO ELIMINADO --> " << tipo_objeto << endl;
	}
	else{
		cout << "\t POSICION VACIA" << endl;
	}
}


void Juego::busqueda_cuadrante(string &nombre, string &cuadrante){

	if(tablero->busqueda_elemento(nombre, cuadrante)){

		cout << "\t ELEMENTO ENCONTRADO" << endl;
	}
	else
		cout << "\t ELEMENTO NO LOCALIZADO" << endl;

}


void Juego::mostrar_info_elemento(int &posicion_x, int &posicion_y){

	if(tablero->obtener_objeto(posicion_x, posicion_y)){

		(tablero->obtener_objeto(posicion_x, posicion_y))->mostrar();

	}
	else
		cout << "\t ~ NO FIGURA UN ELEMENTO EN ESA POSICION ~" << endl;

}


Juego::~Juego(){

	delete tablero;
	delete porcentajes;

}

