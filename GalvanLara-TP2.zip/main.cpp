#include "menu.h"


int main(){


	Menu* menu_juego = new Menu();

	menu_juego->menu_principal();

	delete menu_juego;


	return 0;
}

