#include "agua_bendita.h"

AguaBendita::AguaBendita(string nombre, int coordenada_x, int coordenada_y, int cant_dosis) : Elemento(nombre, coordenada_x, coordenada_y){

	this->cantidad_dosis = cant_dosis;
}



void AguaBendita::mostrar(){

	cout << "\t NOMBRE DEL ELEMENTO --> " << this->nombre << endl;
	cout << "\t CANTIDAD: " << (this->cantidad_dosis) << endl;

}


char AguaBendita::mostrar_caracter(){

	return AGUA_BENDITA;
}


string AguaBendita::tipo_objeto(){

	return ELEMENTO_AGUA;
}


int AguaBendita::devolver_cantidad(){

	return (this->cantidad_dosis);
}

