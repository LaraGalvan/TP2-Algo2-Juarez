#ifndef ESCOPETA_H_
#define ESCOPETA_H_

#include "elemento.h"
#include "constantes.h"

class Escopeta : public Elemento {

public:

	Escopeta(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();

};



#endif /* ESCOPETA_H_ */
