#include "escopeta.h"

Escopeta::Escopeta(string nombre, int coordenada_x, int coordenada_y) : Elemento(nombre, coordenada_x, coordenada_y){

}


void Escopeta::mostrar(){

	cout << "\t NOMBRE DEL OBJETO --> " << this->nombre << endl;
}



char Escopeta::mostrar_caracter(){

	return ESCOPETA;
}


string Escopeta::tipo_objeto(){

	return ELEMENTO_ESCOPETA;
}


int Escopeta::devolver_cantidad(){

	return CANTIDAD_UNO;
}
