#ifndef JUEGO_H_
#define JUEGO_H_

#include "tablero.h"
#include "estadisticas.h"
#include <string>
#include <fstream>
#include <sstream>


class Juego{

private:
	//Atributos
	Tablero* tablero;
	Estadisticas* porcentajes;


public:

	//Costructor
	//PRE: Recibe el nombre del archivo "estado.txt"
	//POST: Se inicializara el juego
	Juego(string archivo);

	//PRE: -
	//POST: Se mostrara por pantalla el tablero con los personajes
	void mostrar_tablero();


	//PRE: -
	//POST: Se llama al método del tipo Tablero que muestra por pantalla el cuadro de estadisticas y porcentajes
	void mostrar_porcentajes();


	//POST: Se le pide un numero entero al usuario que representa una cantidad
	int pedir_cantidad();


	//POST: Devuelve true si el parametro recibido esta dentro del rango valido. False en caso contrario
	bool validar_coordenada_x(int &posicion_x);


	//POST: Devuelve true si el parametro recibido esta dentro del rango valido. False en caso contrario
	bool validar_coordenada_y(int &posicion_y);


	//POST: Se llama al método de la clase Tablero que da de alta a un personaje/objeto
	void dar_alta(string &nombre, int &coordenada_x, int &coordenada_y);


	//POST: Se hace la baja del elemento en la posicion recibida por el usuario
	void dar_baja(int &posicion_x, int &posicion_y);


	//PRE: Recibe el nombre de un elemento/objeto y el nombre de un cuadrante
	//POST: Se realiza la busqueda por cuadrante llamando al método de la clase Tablero, informandole al usuario si se
	//		encontro o no el elemento a buscar
	void busqueda_cuadrante(string &nombre, string &cuadrante);


	//POST: Se muestra por pantalla la informacion de un elemento
	void mostrar_info_elemento(int &posicion_x, int &posicion_y);


	//Destructor
	~Juego();

};


#endif /* JUEGO_H_ */
