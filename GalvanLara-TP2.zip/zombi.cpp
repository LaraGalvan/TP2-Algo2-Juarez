#include "zombi.h"

Zombi::Zombi(string nombre, int coordenada_x, int coordenada_y) : Monstruo(nombre, coordenada_x, coordenada_y){

}



void Zombi::mostrar(){

	cout << "\t NOMBRE ELEMENTO --> " << this->nombre << endl;
}


char Zombi::mostrar_caracter(){

	return ZOMBI;
}


string Zombi::tipo_objeto(){

	return ELEMENTO_ZOMBI;
}


int Zombi::devolver_cantidad(){

	return CANTIDAD_UNO;
}
