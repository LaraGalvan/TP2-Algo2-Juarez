#include "ser.h"

Ser::Ser(string nombre, int coordenada_x, int coordenada_y) : Objeto(nombre, coordenada_x, coordenada_y){

}
