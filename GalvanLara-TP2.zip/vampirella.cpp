#include "vampirella.h"

Vampirella::Vampirella(string nombre, int coordenada_x, int coordenada_y) : Vampiro(nombre, coordenada_x, coordenada_y){

}


void Vampirella::mostrar(){

	cout << "\t NOMBRE PERSONAJE --> " << this->nombre << endl;
}


char Vampirella::mostrar_caracter(){

	return VAMPIRELLA;
}


string Vampirella::tipo_objeto(){

	return ELEMENTO_VAMPIRO;
}

int Vampirella::devolver_cantidad(){

	return CANTIDAD_UNO;
}
