#ifndef MENU_H_
#define MENU_H_

#include "juego.h"

class Menu{


private:

	Juego* juego;


public:

	//Constructor
	//POST: Inicializa el juego
	Menu();


	//POST: Se imprime por pantalla un ascii art
	void mostrar_titulo();


	//POST: Le muestra las opciones del menu principal al usuario
	void mostrar_opciones();


	//POST: La funcion devuelve un entero que representa una de las opciones elegidas
	int pedir_opcion();


	//POST: Devuelve true si las opciones son validas. False en caso contrario
	bool validar_opcion(int &opcion);


	//POST: Se le pide al usuario que ingrese el nombre de un elemento
	string pedir_nombre();


	//POST: Devuelve true si el parametro recibido por parametro es un nombre valido. False en caso contrario
	bool validar_nombre(string &nombre);


	//POST: Devuelve un entero que representa un numero de fila
	int pedir_coordenada_x();


	//POST: Devuelve un entero que representa un numero de columna
	int pedir_coordenada_y();


	//POST: Devuelve NO si el usuario elige el cuadrante noroeste, NE si elige noreste, SO si suroeste o SO si elige suroeste
	string pedir_cuadrante();


	//POST: Devuelve true si el cuadrante elegido es valido. False en caso contrario
	bool validar_cuadrante(string &cuadrante);


	//POST: Se muestra por pantalla un mensaje de despedida
	void despedida();


	//POST: Se le muestra al usuario las opciones del menu y se ejecuta la opcion elegida
	void menu_principal();


	//Destructor
	~Menu();

};


#endif /* MENU_H_ */
