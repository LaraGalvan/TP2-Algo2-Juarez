#include "estadisticas.h"

Estadisticas::Estadisticas(){

	this->cant_humanos = 0;
	this->cant_vampiros = 0;
	this->cant_zombi = 0;
	this->cant_estacas = 0;
	this->cant_escopetas = 0;
	this->cant_cruces = 0;
	this->cant_balas = 0;
	this->cant_agua = 0;
}

void Estadisticas::incrementar_contadores(string elemento){

	if((elemento == ELEMENTO_HUMANO) || (elemento == ELEMENTO_VANESA) || (elemento == ELEMENTO_HUMANOCV)){
		this->cant_humanos = (this->cant_humanos + 1);
	}
	else if(elemento == ELEMENTO_ZOMBI){
		this->cant_zombi = (this->cant_zombi + 1);
	}
	else if(elemento == ELEMENTO_ESTACA){
		this->cant_estacas = (this->cant_estacas + 1);
	}
	else if(elemento == ELEMENTO_ESCOPETA){
		this->cant_escopetas = (this->cant_escopetas + 1);
	}
	else if(elemento == ELEMENTO_CRUZ){
		this->cant_cruces = (this->cant_cruces + 1);
	}
	else{
		this->cant_vampiros = (this->cant_vampiros + 1);
	}
}


void Estadisticas::incrementar_contador_cantidad(string elemento, int cantidad){

	if(elemento == ELEMENTO_AGUA){
		this->cant_agua += cantidad;
	}
	else
		this->cant_balas += cantidad;
}



void Estadisticas::decrementar_contadores(string elemento, int cantidad){

	if(elemento == ELEMENTO_HUMANO){
		//entra Vanesa, humano CV y humano normal
		this->cant_humanos = (this->cant_humanos - cantidad);
	}
	else if(elemento == ELEMENTO_ESTACA){

		this->cant_estacas = (this->cant_estacas - cantidad);
	}
	else if(elemento == ELEMENTO_ESCOPETA){

		this->cant_escopetas = (this->cant_escopetas - cantidad);
	}
	else if(elemento == ELEMENTO_CRUZ){

		this->cant_cruces = (this->cant_cruces - cantidad);
	}
	else if(elemento == ELEMENTO_ZOMBI){

		this->cant_zombi = (this->cant_zombi - cantidad);
	}
	else if(elemento == ELEMENTO_AGUA){

		this->cant_agua = (this->cant_agua - cantidad);
	}
	else if(elemento == ELEMENTO_BALA){

		this->cant_balas = (this->cant_balas - cantidad);
	}
	else{ //entra Nosferatu, Vampirella y vampiro normal
		this->cant_vampiros = (this->cant_vampiros - cantidad);
	}
}



float Estadisticas::porcentaje_humanos(){

	return (((float)this->cant_humanos * 100) / (this->cant_humanos + this->cant_zombi + this->cant_vampiros));
}


float Estadisticas::porcentaje_vampiros(){

	return (((float)this->cant_vampiros * 100) / (this->cant_vampiros + this->cant_humanos + this->cant_zombi));
}


float Estadisticas::porcentaje_zombis(){

	return (((float)this->cant_zombi * 100) / (this->cant_humanos + this->cant_zombi + this->cant_vampiros));
}


float Estadisticas::porcentaje_escopeta(){

	return (((float)this->cant_escopetas * 100) / (this->cant_balas));
}


float Estadisticas::porcentaje_cruces(){

	return (((float)this->cant_cruces * 100) / (this->cant_cruces + this->cant_estacas + this->cant_agua));
}


float Estadisticas::porcentaje_balas(){

	return (((float)this->cant_balas * 100) / (this->cant_escopetas));
}


float Estadisticas::porcentaje_estacas(){

	return (((float)this->cant_estacas * 100) / (this->cant_estacas + this->cant_escopetas + this->cant_agua));
}


float Estadisticas::porcentaje_agua(){

	return ((this->cant_agua * 100)/(this->cant_agua + this->cant_estacas + this->cant_cruces));
}




void Estadisticas::mostrar_estadisticas(){

	cout << endl;
	cout << RESUMEN_ELEMENTO << setw(19) << RESUMEN_CANTIDAD << setw(19) << RESUMEN_PORCENTAJE << endl;
	cout << "----------------------------------------------" << endl;
	cout << RESUMEN_HUMANOS << setw(16) << this->cant_humanos << setw(19) << porcentaje_humanos() << endl;
	cout << RESUMEN_ZOMBIS+ESPACIO << setw(16) << this->cant_zombi << setw(19) << porcentaje_zombis() << endl;
	cout << RESUMEN_VAMPIROS << setw(15) << this->cant_vampiros << setw(19) << porcentaje_vampiros() << endl;
	cout << RESUMEN_AGUA << setw(12) << this->cant_agua << setw(18) << porcentaje_agua() << endl;
	cout << RESUMEN_CRUCES+ESPACIO << setw(16) << this->cant_cruces << setw(19) << porcentaje_cruces() << endl;
	cout << RESUMEN_ESTACAS+ESPACIO << setw(15) << this->cant_estacas << setw(19) << porcentaje_estacas() << endl;
	cout << RESUMEN_ESCOPETAS << setw(14) << this->cant_escopetas << setw(19) << porcentaje_escopeta() << endl;
	cout << RESUMEN_BALAS << setw(18) << this->cant_balas << setw(19) << porcentaje_balas() << endl;
	cout << endl;
}




