#include "menu.h"


Menu::Menu(){

	juego = new Juego(NOMBRE_ARCHIVO);

}


void Menu::mostrar_titulo(){

	cout << "\n";
	cout << "##    ##  #######   ######  ######## ######## ########     ###    ######## ##     ##    #### ####" << endl;
	cout << "###   ## ##     ## ##    ## ##       ##       ##     ##   ## ##      ##    ##     ##     ##   ## " << endl;
	cout << "####  ## ##     ## ##       ##       ##       ##     ##  ##   ##     ##    ##     ##     ##   ## " << endl;
	cout << "## ## ## ##     ##  ######  ######   ######   ########  ##     ##    ##    ##     ##     ##   ##" << endl;
	cout << "##  #### ##     ##       ## ##       ##       ##   ##   #########    ##    ##     ##     ##   ## " << endl;
	cout << "##   ### ##     ## ##    ## ##       ##       ##    ##  ##     ##    ##    ##     ##     ##   ## " << endl;
	cout << "##    ##  #######   ######  ##       ######## ##     ## ##     ##    ##     #######     #### #### " << endl;
	cout << "\n";

}




void Menu::mostrar_opciones(){

	cout << "\n";
	cout << "\t\t\t 1 ~ MOSTRAR TABLERO" << endl;
	cout << "\t\t\t 2 ~ MOSTRAR CUADRO ESTADISTICAS" << endl;
	cout << "\t\t\t 3 ~ BUSQUEDA POR CUADRANTE" << endl;
	cout << "\t\t\t 4 ~ DAR ALTA ELEMENTO" << endl;
	cout << "\t\t\t 5 ~ DAR BAJA ELEMENTO" << endl;
	cout << "\t\t\t 6 ~ BRINDAR INFORMACION DE ELEMENTO" << endl;
	cout << "\t\t\t 0 ~ SALIR" << endl;
}



int Menu::pedir_opcion(){

	int opcion = 0;
	cout << "\n";
	cout << "\t\t\t SELECCIONE UNA OPCION, INGRESANDO UN NUMERO" << endl;
	cout << "\n";
	cout << "---> ";
	cin >> opcion;

	while(!validar_opcion(opcion)){
		cout << "\t\t OPCION INCORRECTA! Por favor ingrese nuevamente" << endl;
		cout << "---> ";
		cin >> opcion;
	}
	return opcion;
}


bool Menu::validar_opcion(int &opcion){

	return ((opcion == MOSTRAR_TABLERO) || (opcion == MOSTRAR_ESTADISTICAS) || (opcion == BUSQUEDA_CUADRANTE) ||
			(opcion == ALTA_ELEMENTO) || (opcion == BAJA_ELEMENTO) || (opcion == INFO_ELEMENTO) ||(opcion == SALIR));
}


bool Menu::validar_nombre(string &nombre){

	return ((nombre == ELEMENTO_HUMANO) || (nombre == ELEMENTO_VAMPIRO) || (nombre == ELEMENTO_ZOMBI) || (nombre == ELEMENTO_CRUZ) ||
			(nombre == ELEMENTO_ESTACA) || (nombre == ELEMENTO_ESCOPETA) || (nombre == ELEMENTO_AGUA) || (nombre == ELEMENTO_BALA) ||
			(nombre == ELEMENTO_VAMPIRELLA) || (nombre == ELEMENTO_NOSFERATU) || (nombre == ELEMENTO_VANESA) ||
			(nombre == ELEMENTO_HUMANOCV));
}



string Menu::pedir_nombre(){

	string nombre;
	cout << "\n";
	cout << "\t\t\t\t INGRESE EL NOMBRE DEL ELEMENTO" << endl;
	cout << "\n";
	cout << "\t\t\t humano			" << setw(5) << "humano CV		" << setw(5) << "Vanesa	" << endl;
	cout << "\t\t\t zombi			" << setw(5) << "vampiro			" << setw(5) << "Vampirella	" << endl;
	cout << "\t\t\t Nosferatu		" << setw(5) << "cruz			" << setw(5) << "agua	" << endl;
	cout << "\t\t\t estaca			" << setw(5) << "escopeta		" << setw(5) << "bala	" << endl;
	cout << "\n --> ";
	cin >> nombre;

	while(!validar_nombre(nombre)){
		cout << "\t\t NOMBRE INVALIDO! Por favor ingrese nuevamente" << endl;
		cout << "\n --> ";
		cin >> nombre;
	}
	return nombre;
}


bool Menu::validar_cuadrante(string &cuadrante){

	return ((cuadrante == NOROESTE) || (cuadrante == NORESTE) || (cuadrante == SUROESTE) || (cuadrante == SURESTE));
}



string Menu::pedir_cuadrante(){

	string cuadrante;

	cout << "\t\t\t Seleccione un cuadrante, ingresando NO, NE, SO, SE" << endl;
	cout << "\n";
	cout << "\t\t\t NO ~ NOROESTE" << endl;
	cout << "\t\t\t NE ~ NORESTE" << endl;
	cout << "\t\t\t SO ~ SUROESTE" << endl;
	cout << "\t\t\t SE ~ SURESTE" << endl;
	cout << "\n---> ";
	cin >> cuadrante;

	while(!validar_cuadrante(cuadrante)){
		cout << "\t\t CUADRANTE INCORRECTO! Por favor ingrese nuevamente";
		cout << "\n---> ";
		cin >> cuadrante;
	}
	return cuadrante;
}


int Menu::pedir_coordenada_x(){

	int posicion_x;
	cout << "\t Ingrese un numero de fila: ";
	cin >> posicion_x;

	while(!(juego->validar_coordenada_x(posicion_x))){

		cout << "\t FILA FUERA DE RANGO! Por favor ingrese nuevamente: ";
		cin >> posicion_x;
	}

	return posicion_x;
}


int Menu::pedir_coordenada_y(){

	int posicion_y;
	cout << "\t Ingrese un numero de columna: ";
	cin >> posicion_y;

	while(!(juego->validar_coordenada_y(posicion_y))){

		cout << "\t COLUMNA FUERA DE RANGO! Por favor ingrese nuevamente: ";
		cin >> posicion_y;
	}
	return posicion_y;
}


void Menu::despedida(){

	cout << "\n";
	cout << ".|''|,  '''|.  '||),,(|,  .|''|,     .|''|, \\   // .|''|, '||''| " << endl;
	cout << "||  || .|''||   || || ||  ||..||     ||  ||  \\ //  ||..||  ||   " << endl;
	cout << "`|..|| `|..||. .||    ||. `|...      `|..|'   ./   `|...  .||. " << endl;
	cout << "    ||                                                        " << endl;
	cout << " `..|'                                                        " << endl;
	cout << "\n";
	cout << "\t\t\t GRACIAS POR JUGAR :D" << endl;
	cout << "\t\t\t TP2 | ALGO2 JUAREZ | 1C 2021" << endl;
}




void Menu::menu_principal(){

	int opcion;
	bool menu_activo = true;
	int posicion_x;
	int posicion_y;
	string nombre;
	string cuadrante;
	mostrar_titulo();

	while(menu_activo){

		mostrar_opciones();
		opcion = pedir_opcion();

		switch(opcion){

			case MOSTRAR_TABLERO:
				juego->mostrar_tablero();
				break;

			case MOSTRAR_ESTADISTICAS:
				juego->mostrar_porcentajes();
				break;

			case BUSQUEDA_CUADRANTE:
				nombre = pedir_nombre();
				cuadrante = pedir_cuadrante();
				juego->busqueda_cuadrante(nombre, cuadrante);
				break;

			case ALTA_ELEMENTO:
				posicion_x = pedir_coordenada_x();
				posicion_y = pedir_coordenada_y();
				nombre = pedir_nombre();
				juego->dar_alta(nombre, posicion_x, posicion_y);
				break;

			case BAJA_ELEMENTO:
				posicion_x = pedir_coordenada_x();
				posicion_y = pedir_coordenada_y();
				juego->dar_baja(posicion_x, posicion_y);
				break;

			case INFO_ELEMENTO:
				posicion_x = pedir_coordenada_x();
				posicion_y = pedir_coordenada_y();
				juego->mostrar_info_elemento(posicion_x, posicion_y);
				break;

			case SALIR:
				despedida();
				menu_activo = false;
				break;

		}
	}
}


Menu::~Menu(){

	delete juego;
}
