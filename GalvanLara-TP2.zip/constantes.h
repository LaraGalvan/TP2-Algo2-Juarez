#ifndef CONSTANTES_H_
#define CONSTANTES_H_

#include <iostream>
using namespace std;

const char VACIO = '*';
const char HUMANO = 'h';
const char HUMANO_CV = 'H';
const char VANESA = 'W';
const char ZOMBI = 'z';
const char VAMPIRO = 'v';
const char VAMPIRELLA = 'V';
const char NOSFERATU = 'N';
const char CRUZ = 'c';
const char AGUA_BENDITA = 'a';
const char ESTACA = 'e';
const char ESCOPETA = 'E';
const char BALAS = 'b';
const string NOMBRE_ARCHIVO = "estado.txt";
const string ERROR_APERTURA_ARCHIVO = "No se pudo abrir el archivo";
const char ESPACIO = ' ';
const string RESUMEN_ELEMENTO = "Elemento";
const string RESUMEN_CANTIDAD = "Cantidad";
const string RESUMEN_PORCENTAJE = "Porcentaje";
const string RESUMEN_HUMANOS = "Humanos";
const string RESUMEN_ZOMBIS = "Zombis";
const string RESUMEN_VAMPIROS = "Vampiros";
const string RESUMEN_AGUA = "Agua bendita";
const string RESUMEN_CRUCES = "Cruces";
const string RESUMEN_ESTACAS = "Estacas";
const string RESUMEN_ESCOPETAS = "Escopetas";
const string RESUMEN_BALAS = "Balas";
const int CANTIDAD_UNO = 1;
const string ELEMENTO_HUMANO = "humano";
const string ELEMENTO_VAMPIRO = "vampiro";
const string ELEMENTO_ZOMBI = "zombi";
const string ELEMENTO_ESTACA = "estaca";
const string ELEMENTO_ESCOPETA = "escopeta";
const string ELEMENTO_CRUZ = "cruz";
const string ELEMENTO_AGUA = "agua";
const string ELEMENTO_BALA = "bala";
const string ELEMENTO_VAMPIRELLA = "Vampirella";
const string ELEMENTO_NOSFERATU = "Nosferatu";
const string ELEMENTO_VANESA = "Vanesa";
const string ELEMENTO_HUMANOCV = "humano CV";
const string NOROESTE = "NO";
const string NORESTE = "NE";
const string SUROESTE = "SO";
const string SURESTE = "SE";
const int SALIR = 0;
const int MOSTRAR_TABLERO = 1;
const int MOSTRAR_ESTADISTICAS = 2;
const int BUSQUEDA_CUADRANTE = 3;
const int ALTA_ELEMENTO = 4;
const int BAJA_ELEMENTO = 5;
const int INFO_ELEMENTO = 6;

#endif /* CONSTANTES_H_ */
