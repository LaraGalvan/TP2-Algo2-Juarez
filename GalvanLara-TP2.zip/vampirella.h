#ifndef VAMPIRELLA_H_
#define VAMPIRELLA_H_

#include "vampiro.h"
#include "constantes.h"

class Vampirella : public Vampiro {

public:
	//constructor
	Vampirella(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();
};


#endif /* VAMPIRELLA_H_ */
