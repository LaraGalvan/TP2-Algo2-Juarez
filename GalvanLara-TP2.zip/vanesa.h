#ifndef VANESA_H_
#define VANESA_H_

#include "humano_cv.h"
#include "constantes.h"

class Vanesa : public HumanoCV {
public:
	//Constructor
	Vanesa(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();

};


#endif /* VANESA_H_ */
