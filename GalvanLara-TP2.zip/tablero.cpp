#include "tablero.h"


Tablero::Tablero(int filas, int columnas){

	this->filas = filas;
	this->columnas = columnas;
	matriz = new Objeto**[filas];

	for(int i = 0; i < filas; i++){
		matriz[i] = new Objeto*[columnas];
	}
	for(int i = 0; i < filas; i++){
		for(int j = 0; j < columnas; j++){
			matriz[i][j] = nullptr;
		}
	}

	cuadrantes[0] = Cuadrante("NO", 0, filas/2, 0, columnas/2);
	cuadrantes[1] = Cuadrante("NE", 0, filas/2, columnas/2, columnas);
	cuadrantes[2] = Cuadrante("SO", filas/2, filas, 0, columnas/2);
	cuadrantes[3] = Cuadrante("SE", filas/2, filas, columnas/2, columnas);

}


bool Tablero::agregar_elemento(string elemento, int coordenada_x, int coordenada_y){

	bool alta_aceptada = false;

	if(!matriz[coordenada_x][coordenada_y]){

		Objeto *objeto_nuevo = crear_elementos(elemento, coordenada_x, coordenada_y);
		matriz[coordenada_x][coordenada_y] = objeto_nuevo;
		alta_aceptada = true;
	}
	return alta_aceptada;

}


bool Tablero::agregar_elementos_cantidad(string elemento, int coordenada_x, int coordenada_y, int cantidad){

	bool alta_aceptada = false;

	if(!matriz[coordenada_x][coordenada_y]){

		Objeto *objeto = crear_elemento_cantidad(elemento, coordenada_x, coordenada_y, cantidad);
		matriz[coordenada_x][coordenada_y] = objeto;
		alta_aceptada = true;
	}
	return alta_aceptada;
}


Objeto* Tablero::crear_elementos(string elemento, int coordenada_x, int coordenada_y){

	if(elemento == "humano"){
		return new Humano(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "Vanesa"){
		return new Vanesa(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "humano CV"){
		return new HumanoCV(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "vampiro"){
		return new Vampiro(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "zombi"){
		return new Zombi(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "Nosferatu"){
		return new Nosferatu(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "Vampirella"){
		return new Vampirella(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "estaca"){
		return new Estaca(elemento, coordenada_x, coordenada_y);
	}
	else if(elemento == "escopeta"){
		return new Escopeta(elemento, coordenada_x, coordenada_y);
	}
	else{
		return new Cruz(elemento, coordenada_x, coordenada_y);
	}
}


Objeto* Tablero::crear_elemento_cantidad(string elemento, int coordenada_x, int coordenada_y, int cantidad){

	if(elemento == "agua"){
		return new AguaBendita(elemento, coordenada_x, coordenada_y, cantidad);
	}
	return new Bala(elemento, coordenada_x, coordenada_y, cantidad);
}




void Tablero::imprimir_tablero(){

	for(int i = 0; i < this->filas+1; i++){
		for(int j = 0; j < this->columnas+1; j++){

			if(i == 0){
				if(j < this->columnas){

					if(j == 0)
						cout << setw(23) << ESPACIO << ESPACIO << ESPACIO << ESPACIO << j;
					else if(j < 10)
						cout << ESPACIO << ESPACIO << j;
					else
						cout << ESPACIO << j;
				}
			}
			else{
				if(j == 0)
					cout << setw(24) << i-1 << ESPACIO;
				else
					if(matriz[i-1][j-1]){
						cout << ESPACIO << matriz[i-1][j-1]->mostrar_caracter() << ESPACIO;
					}
					else{
						cout << ESPACIO << VACIO << ESPACIO;
					}
			}
		}
		cout << "\n";
	}
}


Objeto* Tablero::obtener_objeto(int pos_x, int pos_y){

	return (matriz[pos_x][pos_y]);
}



void Tablero::dar_baja(int pos_x, int pos_y){

	delete (matriz[pos_x][pos_y]);

	(matriz[pos_x][pos_y]) = nullptr;
}


Cuadrante Tablero::devolver_cuadrante(string cuadrante_ingresado){

	Cuadrante seleccionado;
	for(int i = 0; i < 4; i++){

		if(cuadrantes[i].obtener_nombre() == cuadrante_ingresado){
			seleccionado = cuadrantes[i];
		}
	}
	return seleccionado;
}


bool Tablero::busqueda_elemento(string buscado, string cuadrante_ingresado){

	Cuadrante cuadrante_elegido = devolver_cuadrante(cuadrante_ingresado);
	bool encontrado = false;

	for(int i = cuadrante_elegido.obtener_minimo_x(); i < cuadrante_elegido.obtener_maximo_x(); i++){
		for(int j = cuadrante_elegido.obtener_minimo_y(); j < cuadrante_elegido.obtener_maximo_y(); j++){

			if(matriz[i][j] != 0){

				if(matriz[i][j]->devolver_nombre() == buscado){
					encontrado = true;
				}
			}
		}
	}
	return encontrado;
}


int Tablero::devolver_filas(){

	return (this->filas);
}


int Tablero::devolver_columnas(){

	return (this->columnas);
}



Tablero::~Tablero(){

	for(int i = 0; i < filas; i++){
		for(int j = 0; j < columnas; j++){
			if(matriz[i][j] != nullptr){

				delete matriz[i][j];
			}
		}
	}
	for(int i = 0; i < filas; i++){
		delete[] matriz[i];
		matriz[i] = nullptr;
	}

	delete [] matriz;
	matriz = nullptr;

}


