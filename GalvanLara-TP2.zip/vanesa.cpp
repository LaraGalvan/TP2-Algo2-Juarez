#include "vanesa.h"

Vanesa::Vanesa(string nombre, int coordenada_x, int coordenada_y) : HumanoCV(nombre, coordenada_x, coordenada_y){

}


void Vanesa::mostrar(){

	cout << "\t NOMBRE PERSONAJE --> " << this->nombre << endl;
}


char Vanesa::mostrar_caracter(){

	return VANESA;
}

string Vanesa::tipo_objeto(){

	return ELEMENTO_HUMANO;
}


int Vanesa::devolver_cantidad(){

	return CANTIDAD_UNO;
}
