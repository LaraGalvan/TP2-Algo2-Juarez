#include "vampiro.h"

Vampiro::Vampiro(string nombre, int coordenada_x, int coordenada_y) : Monstruo(nombre, coordenada_x, coordenada_y){

}


void Vampiro::mostrar(){

	cout << "\t NOMBRE PERSONAJE --> " << this->nombre << endl;
}


char Vampiro::mostrar_caracter(){

	return VAMPIRO;
}

string Vampiro::tipo_objeto(){

	return ELEMENTO_VAMPIRO;
}


int Vampiro::devolver_cantidad(){

	return CANTIDAD_UNO;
}
