#ifndef CUADRANTE_H_
#define CUADRANTE_H_

#include "constantes.h"

class Cuadrante{

private:
	//Atributos
	string nombre;
	int minimo_x;
	int maximo_x;
	int minimo_y;
	int maximo_y;

public:
	//Constructor sin parametros
	Cuadrante();

	//Constructor con parametros
	//POST: Se inicializan los atributos
	Cuadrante(string nombre, int minimo_x, int maximo_x, int minimo_y, int maximo_y);


	//POST: Devuelve el atributo nombre
	string obtener_nombre();


	//POST: Devuelve el atributo minimo x
	int obtener_minimo_x();


	//POST: Devuelve el atributo maximo x
	int obtener_maximo_x();


	//POST: Devuelve el atributo minimo y
	int obtener_minimo_y();


	//POST: Devuelve el atributo maximo y
	int obtener_maximo_y();


	//Destructor
	~Cuadrante(){};
};



#endif /* CUADRANTE_H_ */
