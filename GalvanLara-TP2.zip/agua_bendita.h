#ifndef AGUA_BENDITA_H_
#define AGUA_BENDITA_H_

#include "elemento.h"
#include "constantes.h"

class AguaBendita : public Elemento {

private:
	int cantidad_dosis;

public:
	//Constructor
	AguaBendita(string nombre, int coordenada_x, int coordenada_y, int cant_dosis);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	//POST: Devuelve la cantidad asociada al elemento
	int devolver_cantidad();


};



#endif /* AGUA_BENDITA_H_ */
