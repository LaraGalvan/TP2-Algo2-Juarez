#include "objeto.h"

Objeto::Objeto(string nombre, int coordenada_x, int coordenada_y){

	this->nombre = nombre;
	this->coordenada_x = coordenada_x;
	this->coordenada_y = coordenada_y;

}

Objeto::~Objeto() {}


string Objeto::devolver_nombre(){

	return (this->nombre);
}
