#include "cruz.h"

Cruz::Cruz(string nombre, int coordenada_x, int coordenada_y) : Elemento(nombre, coordenada_x, coordenada_y){

}


void Cruz::mostrar(){

	cout << "\t NOMBRE DEL OBJETO --> " << this->nombre << endl;
}



char Cruz::mostrar_caracter(){

	return CRUZ;
}


string Cruz::tipo_objeto(){

	return ELEMENTO_CRUZ;
}


int Cruz::devolver_cantidad(){

	return CANTIDAD_UNO;
}
