#ifndef TABLERO_H_
#define TABLERO_H_

#include "objeto.h"
#include "elemento.h"
#include "escopeta.h"
#include "estaca.h"
#include "cruz.h"
#include "agua_bendita.h"
#include "bala.h"
#include "cuadrante.h"
#include "ser.h"
#include "humano.h"
#include "humano_cv.h"
#include "vanesa.h"
#include "monstruo.h"
#include "zombi.h"
#include "vampiro.h"
#include "nosferatu.h"
#include "vampirella.h"
#include <iomanip>

class Tablero {

private:
	//Atributos
	int filas;
	int columnas;
	Objeto ***matriz;
	Cuadrante cuadrantes[4];


public:
	//Métodos

	//PRE: Recibe dos enteros que representan las filas y las columnas del tablero
	//POST: Se le asignan los parametros a los atributos
	Tablero(int filas, int columnas);


	//PRE: Recibe un elemento del tipo string, junto a su coordenada
	//POST: Devuelve true si se pudo agregar el elemento de tipo Objeto (sin cantidad). False en caso contrario
	bool agregar_elemento(string elemento, int coordenada_x, int coordenada_y);


	//POST: Devuelve true si se pudo agregar el elemento con cantidad de tipo Objeto al tablero. False en caso contrario
	bool agregar_elementos_cantidad(string elemento, int coordenada_x, int coordenada_y, int cantidad);


	//PRE: Recibe un elemento del tipo string junto a sus coordenadas
	//POST: Se crean los elementos del tipo Objeto
	Objeto* crear_elementos(string elemento, int coordenada_x, int coordenada_y);


	//PRE: Recibe un elemento del tipo string, junto a sus coordenadas y cantidad
	//POST: Se crean los elementos de tipo Objeto que tienen cantidad asociada
	Objeto* crear_elemento_cantidad(string elemento, int coordenada_x, int coordenada_y, int cantidad);


	//PRE: Recibe dos numeros enteros que representan una coordenada (x, y)
	//POST: Elimina el objeto del tablero y lo deja apuntando a vacio
	void dar_baja(int pos_x, int pos_y);


	//PRE: recibe dos enteros que representan una coordenada
	//POST: Devuelve un elemento del tablero de tipo Objeto
	Objeto* obtener_objeto(int pos_x, int po_y);


	//PRE: -
	//POST: Se imprime el tablero con los elementos y caracteres correspondientes
	void imprimir_tablero();


	//PRE: Recibe el nombre del elemento a buscar y el nombre de un cuadrante
	//POST: Devuelve true si el nombre recibido por parametro coincide con el nombre del elemento del tablero
	bool busqueda_elemento(string buscado, string cuadrante);


	//POST: Devuelve un entero que representa el numero de filas
	int devolver_filas();


	//POST: Devuelve un entero que representa el numero de columnas
	int devolver_columnas();


	//Destructor
	//POST: Se recorre el tablero y se eliminan los elementos del tipo Objeto
	~Tablero();


private:
	//PRE: Recibe el nombre del cuadrante ingresado por el usuario
	//POST: Devuelve el cuadrante cuyo nombre coincida con el recibido por parametro
	Cuadrante devolver_cuadrante(string cuadrante_ingresado);

};

#endif /* TABLERO_H_ */
