#include "nosferatu.h"

Nosferatu::Nosferatu(string nombre, int coordenada_x, int coordenada_y) : Vampiro(nombre, coordenada_x, coordenada_y) {

}


void Nosferatu::mostrar(){

	cout << "\t NOMBRE PERSONAJE --> " << this->nombre << endl;
}


char Nosferatu::mostrar_caracter(){

	return NOSFERATU;
}


string Nosferatu::tipo_objeto(){

	return ELEMENTO_VAMPIRO;
}

int Nosferatu::devolver_cantidad(){

	return CANTIDAD_UNO;
}
