#ifndef ZOMBI_H_
#define ZOMBI_H_

#include "monstruo.h"
#include "constantes.h"

class Zombi : public Monstruo {

public:
	//constructor
	Zombi(string nombre, int coordenada_x, int coordenada_y);


	void mostrar();


	char mostrar_caracter();


	string tipo_objeto();


	int devolver_cantidad();
};



#endif /* ZOMBI_H_ */
