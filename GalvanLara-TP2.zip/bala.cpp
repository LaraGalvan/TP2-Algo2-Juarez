#include "bala.h"

Bala::Bala(string nombre, int coordenada_x, int coordenada_y, int balas) : Elemento(nombre, coordenada_x, coordenada_y){

	this->cantidad_balas = balas;
}



void Bala::mostrar(){

	cout << "\t NOMBRE DEL ELEMENTO --> " << this->nombre << endl;
	cout << "\t CANTIDAD: " << (this->cantidad_balas) << endl;
}



char Bala::mostrar_caracter(){

	return BALAS;
}


string Bala::tipo_objeto(){

	return ELEMENTO_BALA;
}


int Bala::devolver_cantidad(){

	return (this->cantidad_balas);
}

