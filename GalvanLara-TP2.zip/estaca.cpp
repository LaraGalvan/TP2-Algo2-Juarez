#include "estaca.h"

Estaca::Estaca(string nombre, int coordenada_x, int coordenada_y) : Elemento(nombre, coordenada_x, coordenada_y){

}


void Estaca::mostrar(){

	cout << "\t NOMBRE DEL OBJETO -->" << this->nombre << endl;
}


char Estaca::mostrar_caracter(){

	return ESTACA;
}


string Estaca::tipo_objeto(){

	return ELEMENTO_ESTACA;
}


int Estaca::devolver_cantidad(){

	return CANTIDAD_UNO;
}
